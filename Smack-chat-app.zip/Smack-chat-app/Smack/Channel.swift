//
//  Channel.swift
//  Smack
//
//  Created by akshay Grover on 2017-08-12.
//  Copyright © 2017 akshay Grover. All rights reserved.
//

import Foundation

struct Channel   {
    
    public private(set) var channelTitle: String!
    public private(set) var channelDescription: String!
    public private(set) var id: String!
    
}
