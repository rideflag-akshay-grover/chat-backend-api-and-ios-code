import mongodb from 'mongodb';

export default {
  // "port": 3005,
  // "mongoUrl": "mongodb://localhost:27017/chat-api",
  "port": process.env.PORT,
  "mongoUrl": "mongodb://akshay:123456@ds161038.mlab.com:61038/chatapp",
  "bodyLimit": "100kb"
}
